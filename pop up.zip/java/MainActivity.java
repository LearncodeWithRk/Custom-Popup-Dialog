package in.learncodewithrk.googlelogin;



import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity  {

    Button btn_positive, btn_negative;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn_negative = findViewById(R.id.btn_negative);
        btn_positive = findViewById(R.id.btn_positive);
        btn_positive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPositivePopupDialog();
            }
        });
        btn_negative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showNegativePopupDialog();
            }
        });
    }
    public void showPositivePopupDialog() {
        final Dialog popup_dialog;
        Button btn_continue;
        ImageView iv_close;
        popup_dialog = new Dialog(MainActivity.this);
        popup_dialog.show();
        popup_dialog.setContentView(R.layout.popup_dialog_positive);
        iv_close = (ImageView) popup_dialog.findViewById(R.id.iv_closePopupPositiveImg);
        btn_continue = (Button) popup_dialog.findViewById(R.id.btn_loginPopupPositiveImg);
        popup_dialog.getWindow().setBackgroundDrawableResource(
                android.R.color.transparent
        );
        iv_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popup_dialog.dismiss();
            }
        });
        btn_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popup_dialog.dismiss();
            }
        });
        popup_dialog.setCanceledOnTouchOutside(false);
        popup_dialog.setCancelable(false);
    }
    public void showNegativePopupDialog() {
        final Dialog popup_dialog;
        Button btn_continue;
        ImageView iv_close;
        popup_dialog = new Dialog(MainActivity.this);
        popup_dialog.show();
        popup_dialog.setContentView(R.layout.popup_dialog_negative);
        iv_close = (ImageView) popup_dialog.findViewById(R.id.iv_closePopupNegativeImg);
        btn_continue = (Button) popup_dialog.findViewById(R.id.btn_closePopupNegativeImg);
        popup_dialog.getWindow().setBackgroundDrawableResource(
                android.R.color.transparent
        );
        iv_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popup_dialog.dismiss();
            }
        });
        btn_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popup_dialog.dismiss();
            }
        });
        popup_dialog.setCanceledOnTouchOutside(false);
        popup_dialog.setCancelable(false);
    }
}